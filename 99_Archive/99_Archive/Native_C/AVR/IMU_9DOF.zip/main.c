/*
 * main.c
 *
 *  Created on: 2011. 1. 12.
 *      Author: sckim
 */

