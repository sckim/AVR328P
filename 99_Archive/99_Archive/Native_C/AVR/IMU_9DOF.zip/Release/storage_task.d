storage_task.d storage_task.o: ../storage_task.c ../config.h \
  ../compiler.h ../conf_scheduler.h ../stk_526.h ../conf_usb.h \
  ../storage_task.h ../usb_drv.h ../usb_descriptors.h \
  ../usb_standard_request.h ../usb_task.h ../usb_specific_request.h \
  ../scsi_decoder.h ../ctrl_access.h ../conf_access.h ../ctrl_status.h \
  ../df_mem.h ../df.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../storage_task.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../usb_task.h:

../usb_specific_request.h:

../scsi_decoder.h:

../ctrl_access.h:

../conf_access.h:

../ctrl_status.h:

../df_mem.h:

../df.h:
