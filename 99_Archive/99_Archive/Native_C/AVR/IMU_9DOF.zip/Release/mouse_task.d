mouse_task.d mouse_task.o: ../mouse_task.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../conf_usb.h ../mouse_task.h \
  ../usb_drv.h ../usb_descriptors.h ../usb_standard_request.h \
  ../usb_task.h ../wdt_drv.h ../power_drv.h ../pll_drv.h \
  ../at90usb162_quickstart_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../mouse_task.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../usb_task.h:

../wdt_drv.h:

../power_drv.h:

../pll_drv.h:

../at90usb162_quickstart_drv.h:
