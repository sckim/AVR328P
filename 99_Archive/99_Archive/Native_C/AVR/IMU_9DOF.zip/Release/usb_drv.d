usb_drv.d usb_drv.o: ../usb_drv.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../conf_usb.h ../usb_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../usb_drv.h:
