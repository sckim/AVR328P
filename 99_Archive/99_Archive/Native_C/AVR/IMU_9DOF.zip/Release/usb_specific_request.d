usb_specific_request.d usb_specific_request.o: ../usb_specific_request.c \
  ../config.h ../compiler.h ../conf_scheduler.h ../stk_526.h \
  ../conf_usb.h ../usb_drv.h ../usb_descriptors.h \
  ../usb_standard_request.h ../usb_task.h ../usb_specific_request.h \
  ../ctrl_access.h ../conf_access.h ../ctrl_status.h ../df_mem.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../usb_task.h:

../usb_specific_request.h:

../ctrl_access.h:

../conf_access.h:

../ctrl_status.h:

../df_mem.h:
