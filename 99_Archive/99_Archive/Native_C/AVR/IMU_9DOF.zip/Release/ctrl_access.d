ctrl_access.d ctrl_access.o: ../ctrl_access.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../ctrl_access.h ../conf_access.h \
  ../ctrl_status.h ../df_mem.h ../usb_drv.h ../conf_usb.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../ctrl_access.h:

../conf_access.h:

../ctrl_status.h:

../df_mem.h:

../usb_drv.h:

../conf_usb.h:
