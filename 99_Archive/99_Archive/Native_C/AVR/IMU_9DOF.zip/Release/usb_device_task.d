usb_device_task.d usb_device_task.o: ../usb_device_task.c ../config.h \
  ../compiler.h ../conf_scheduler.h ../stk_526.h ../conf_usb.h \
  ../usb_device_task.h ../usb_task.h ../usb_drv.h ../usb_descriptors.h \
  ../usb_standard_request.h ../pll_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../usb_device_task.h:

../usb_task.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../pll_drv.h:
