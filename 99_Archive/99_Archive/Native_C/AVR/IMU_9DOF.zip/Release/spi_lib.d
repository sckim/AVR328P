spi_lib.d spi_lib.o: ../spi_lib.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../spi_lib.h ../spi_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../spi_lib.h:

../spi_drv.h:
