scsi_decoder.d scsi_decoder.o: ../scsi_decoder.c ../config.h \
  ../compiler.h ../conf_scheduler.h ../stk_526.h ../scsi_decoder.h \
  ../conf_usb.h ../usb_drv.h ../ctrl_status.h ../ctrl_access.h \
  ../conf_access.h ../df_mem.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../scsi_decoder.h:

../conf_usb.h:

../usb_drv.h:

../ctrl_status.h:

../ctrl_access.h:

../conf_access.h:

../df_mem.h:
