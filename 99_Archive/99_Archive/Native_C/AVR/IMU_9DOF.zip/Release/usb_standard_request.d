usb_standard_request.d usb_standard_request.o: ../usb_standard_request.c \
  ../config.h ../compiler.h ../conf_scheduler.h ../stk_526.h \
  ../conf_usb.h ../usb_drv.h ../usb_descriptors.h \
  ../usb_standard_request.h ../usb_task.h ../usb_specific_request.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../usb_task.h:

../usb_specific_request.h:
