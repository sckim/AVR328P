power_drv.d power_drv.o: ../power_drv.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../power_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../power_drv.h:
