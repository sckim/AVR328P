################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../at90usb162_quickstart_drv.c \
../ctrl_access.c \
../df.c \
../df_mem.c \
../main.c \
../mouse_task.c \
../power_drv.c \
../scheduler.c \
../scsi_decoder.c \
../spi_lib.c \
../storage_task.c \
../usb_descriptors.c \
../usb_device_task.c \
../usb_drv.c \
../usb_specific_request.c \
../usb_standard_request.c \
../usb_task.c 

OBJS += \
./at90usb162_quickstart_drv.o \
./ctrl_access.o \
./df.o \
./df_mem.o \
./main.o \
./mouse_task.o \
./power_drv.o \
./scheduler.o \
./scsi_decoder.o \
./spi_lib.o \
./storage_task.o \
./usb_descriptors.o \
./usb_device_task.o \
./usb_drv.o \
./usb_specific_request.o \
./usb_standard_request.o \
./usb_task.o 

C_DEPS += \
./at90usb162_quickstart_drv.d \
./ctrl_access.d \
./df.d \
./df_mem.d \
./main.d \
./mouse_task.d \
./power_drv.d \
./scheduler.d \
./scsi_decoder.d \
./spi_lib.d \
./storage_task.d \
./usb_descriptors.d \
./usb_device_task.d \
./usb_drv.d \
./usb_specific_request.d \
./usb_standard_request.d \
./usb_task.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -Os -fpack-struct -fshort-enums -funsigned-char -funsigned-bitfields -mmcu=at90usb162 -DF_CPU=16000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@:%.o=%.d)" -c -o"$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


