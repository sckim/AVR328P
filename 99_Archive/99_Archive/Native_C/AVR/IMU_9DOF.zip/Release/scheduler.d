scheduler.d scheduler.o: ../scheduler.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../scheduler.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../scheduler.h:
