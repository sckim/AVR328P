df.d df.o: ../df.c ../config.h ../compiler.h ../conf_scheduler.h \
  ../stk_526.h ../usb_drv.h ../spi_drv.h ../df.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../usb_drv.h:

../spi_drv.h:

../df.h:
