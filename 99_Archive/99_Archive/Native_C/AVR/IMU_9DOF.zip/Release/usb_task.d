usb_task.d usb_task.o: ../usb_task.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../conf_usb.h ../usb_task.h \
  ../usb_drv.h ../usb_descriptors.h ../usb_standard_request.h \
  ../power_drv.h ../wdt_drv.h ../pll_drv.h ../usb_device_task.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../conf_usb.h:

../usb_task.h:

../usb_drv.h:

../usb_descriptors.h:

../usb_standard_request.h:

../power_drv.h:

../wdt_drv.h:

../pll_drv.h:

../usb_device_task.h:
