main.d main.o: ../main.c ../config.h ../compiler.h ../conf_scheduler.h \
  ../stk_526.h ../scheduler.h ../wdt_drv.h ../power_drv.h ../usb_drv.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../scheduler.h:

../wdt_drv.h:

../power_drv.h:

../usb_drv.h:
