df_mem.d df_mem.o: ../df_mem.c ../config.h ../compiler.h \
  ../conf_scheduler.h ../stk_526.h ../df_mem.h ../conf_access.h \
  ../ctrl_status.h ../usb_drv.h ../df.h

../config.h:

../compiler.h:

../conf_scheduler.h:

../stk_526.h:

../df_mem.h:

../conf_access.h:

../ctrl_status.h:

../usb_drv.h:

../df.h:
