at90usb162_quickstart_drv.d at90usb162_quickstart_drv.o:  \
 ../at90usb162_quickstart_drv.c
